create function st_roughness(rast raster, nband integer DEFAULT 1, pixeltype text DEFAULT '32BF'::text, interpolate_nodata boolean DEFAULT false)
  returns raster
immutable
parallel safe
language sql
as $$
SELECT public.ST_roughness($1, $2, NULL::raster, $3, $4)
$$;

alter function st_roughness(raster, integer, text, boolean)
  owner to postgres;

