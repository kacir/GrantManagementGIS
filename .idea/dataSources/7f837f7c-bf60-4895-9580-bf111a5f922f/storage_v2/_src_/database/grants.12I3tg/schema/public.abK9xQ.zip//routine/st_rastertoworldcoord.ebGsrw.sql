create function st_rastertoworldcoord(rast raster, columnx integer, rowy integer, OUT longitude double precision, OUT latitude double precision)
  returns record
immutable
strict
parallel safe
language sql
as $$
SELECT longitude, latitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;

comment on function st_rastertoworldcoord(raster, integer, integer, out double precision, out double precision)
is 'args: rast, xcolumn, yrow - Returns the rasters upper left corner as geometric X and Y (longitude and latitude) given a column and row. Column and row starts at 1.';

alter function st_rastertoworldcoord(raster, integer, integer, out double precision, out double precision)
  owner to postgres;

