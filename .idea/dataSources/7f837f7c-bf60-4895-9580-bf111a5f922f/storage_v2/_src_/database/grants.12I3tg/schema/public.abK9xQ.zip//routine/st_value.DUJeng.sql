create function st_value(rast raster, band integer, pt geometry, exclude_nodata_value boolean DEFAULT true)
  returns double precision
immutable
strict
parallel safe
language plpgsql
as $$
DECLARE
        x float8;
        y float8;
        gtype text;
    BEGIN
        gtype := public.ST_GeometryType(pt);
        IF ( gtype != 'ST_Point' ) THEN
            RAISE EXCEPTION 'Attempting to get the value of a pixel with a non-point geometry';
        END IF;

				IF public.ST_SRID(pt) != public.ST_SRID(rast) THEN
            RAISE EXCEPTION 'Raster and geometry do not have the same SRID';
				END IF;

        x := public.ST_x(pt);
        y := public.ST_y(pt);
        RETURN public.ST_value(rast,
                        band,
                        public.ST_worldtorastercoordx(rast, x, y),
                        public.ST_worldtorastercoordy(rast, x, y),
                        exclude_nodata_value);
    END;
$$;

comment on function st_value(raster, integer, geometry, boolean)
is 'args: rast, band, pt, exclude_nodata_value=true - Returns the value of a given band in a given columnx, rowy pixel or at a particular geometric point. Band numbers start at 1 and assumed to be 1 if not specified. If exclude_nodata_value is set to false, then all pixels include nodata pixels are considered to intersect and return value. If exclude_nodata_value is not passed in then reads it from metadata of raster.';

alter function st_value(raster, integer, geometry, boolean)
  owner to postgres;

